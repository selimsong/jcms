<form id="ajaxlogin">
	<?=lang('user_name')?><input type="text" name="user_name" id="user_name" ><br>
	<?=lang('user_pass')?><input type="password" name="user_pass" id="user_pass" >
</form>