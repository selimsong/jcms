<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=lang('system_name')?><?=lang('system_version')?> - <?=lang('system_author')?></title>
<link rel="shortcut icon" href="<?=base_url('images/favicon.ico')?>" />
<style>
html,body,div{width:100%;font-family:"Microsoft Yahei", Tahoma, Arial, Helvetica, STHeiti;background-color:#E2E9EA;line-height:20px;padding:0;margin:0;text-align:center;font-size:12px;color:#666;}
a{color:#666;}
</style>
</head><body>
<div><?=lang('system_adminname')?> <?=lang('system_version')?></div>
</body></html>
