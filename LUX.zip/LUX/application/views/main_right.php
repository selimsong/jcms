<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=lang('system_name')?><?=lang('system_version')?> - <?=lang('system_author')?></title>
<style>
body {margin: 0;padding: 0;background:#E2E9EA ;}
</style>
</head>
<body>
<table>		
</table>
</body></html>