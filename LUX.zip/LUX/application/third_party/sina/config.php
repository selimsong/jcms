<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '3371428860' );
define( "WB_SKEY" , '9878595d37d11ed9e1374d78959fb700' );
define( "WB_CALLBACK_URL" , 'http://weiboapp.wood-spring.com/index.php?/sina/callback' );