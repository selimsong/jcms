<?php
$config['cur_tag_open'] = '<span>';
$config['cur_tag_close'] = '</span>';
$config['use_page_numbers'] = TRUE;
$config['first_link'] = lang('first_page');
$config['prev_link'] = lang('pre_page');
$config['next_link'] = lang('next_page');
$config['last_link'] = lang('last_page');
$config['num_links'] = 5;
